 create database Integradora;
 USE Integradora;
 
CREATE TABLE  USUARIOS(
id int not null auto_increment primary key,
nombre varchar(150),
correo varchar(150),
usuario varchar(150),
contrasenia char(12)
);
 
 INSERT INTO Usuarios (nombre, correo, usuario,contrasenia)
 VALUES ("ivan", "utm22030621@utma.edu.mx", "ivan","12345");
 
  INSERT INTO Usuarios (nombre, correo, usuario,contrasenia)
 VALUES ("barbara", "utm22030620@utma.edu.mx", "barbara","12345");
  INSERT INTO Usuarios (nombre, correo, usuario,contrasenia)
 VALUES ("mickey", "utm220630@utma.edu.mx", "mickey","12345");
  INSERT INTO Usuarios (nombre, correo, usuario,contrasenia)
 VALUES ("karla", "utm22030623@utma.edu.mx", "karla","12345");
  INSERT INTO Usuarios (nombre, correo, usuario,contrasenia)
 VALUES ("daniel", "utm22030623@utma.edu.mx", "daniel","12345");
 
select * from usuarios ;